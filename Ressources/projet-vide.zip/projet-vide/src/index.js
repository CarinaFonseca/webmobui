alert('hello !')
